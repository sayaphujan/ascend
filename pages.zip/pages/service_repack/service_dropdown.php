<?php
  
    //options array configuration
    $options = [
    
                'assemblies_service' => [
                                

                                '',
                                '',
                                '',
                                '',
                                '',
                                '',
                                '',
                                '',
                                '',
                                '',
                                '',
                                ''
                            ],
                'wingsize' =>    [
                                            //'Kush or Spacer Foam *BLACK ONLY*',
											'',
                                            '67',
                                            //'69', client ask to remove
                                            '71',
                                            '75',
                                            '79',
                                            '84',
                                            '90',
                                            '96',
                                        ],
                                        
                'color_options' =>    [
                                            'Black and White STD',
                                            'Hot Pink* STD',
                                            'Electric Blue STD',
                                            //'Custom Color +$110',
                                            'Custom Color +$200',
                                        ],
                                        
                

                'ft30' =>    [     
                                            'Electric Blue' => '#00548F',
                                            'Black' => '#010101',
                                            'White' => '#FFFFFF',
                                            'Hot Pink*' => '#FF5C98',
                                        ],    

                'zp' =>    [     
                                            'Black' => '#292425',
                                            'Hot Pink*' => '#E62174',
                                            'Lemon*' => '#BAB543',
                                            'Lime*' => '#62A54D',
                                            'Tangerine' => '#F38032',
                                            'Orchid' => '#5C358D',
                                            'Red' => '#C32341',
                                            'Royal Blue' => '#2E398B',
                                            'Silver' => '#888B8C',
                                            'Electric Blue' => '#1B6798',
                                            'White' => '#F6F4F5',
                                        ],    
                                        
                'ribs_color' =>    [   
                                            'Black' => '#010101',
                                            'White' => '#FFFFFF',
                                        ],    
                                        
                'miniribs_color' =>    [   
                                            'Black' => '#010101',
                                            'White' => '#FFFFFF',
                                        ],  
                
                'xbraces_color' =>    [   
                                            'Black' => '#010101',
                                            'White' => '#FFFFFF',
                                        ],  
                
                'ssdbag' =>           [   
                                            'No',
                                            //'Yes +$160',
                                            'Yes +$155',
                                        ],  

                'rds' =>           [   
                                            'Standard',
                                            'Yes +$315',
                                        ],  
                                        
                'vectran_lines' =>      [   
                                            '400lb',
                                            //'575lb',
                                        ], 
                                        
                'status' =>      [   
                                            'Processing',
                                            'Paid',
                                            'Completed',
                                        ],   
                
                'country' =>    [
                                    "United States",
                                    "Afghanistan",
                                    "Åland Islands",
                                    "Albania",
                                    "Algeria",
                                    "American Samoa",
                                    "Andorra",
                                    "Angola",
                                    "Anguilla",
                                    "Antarctica",
                                    "Antigua and Barbuda",
                                    "Argentina",
                                    "Armenia",
                                    "Aruba",
                                    "Australia",
                                    "Austria",
                                    "Azerbaijan",
                                    "Bahamas",
                                    "Bahrain",
                                    "Bangladesh",
                                    "Barbados",
                                    "Belarus",
                                    "Belgium",
                                    "Belize",
                                    "Benin",
                                    "Bermuda",
                                    "Bhutan",
                                    "Bolivia",
                                    "Bosnia and Herzegovina",
                                    "Botswana",
                                    "Bouvet Island",
                                    "Brazil",
                                    "British Indian Ocean Territory",
                                    "Brunei Darussalam",
                                    "Bulgaria",
                                    "Burkina Faso",
                                    "Burundi",
                                    "Cambodia",
                                    "Cameroon",
                                    "Canada",
                                    "Cape Verde",
                                    "Cayman Islands",
                                    "Central African Republic",
                                    "Chad",
                                    "Chile",
                                    "China",
                                    "Christmas Island",
                                    "Cocos (Keeling) Islands",
                                    "Colombia",
                                    "Comoros",
                                    "Congo",
                                    "Congo, The Democratic Republic of The",
                                    "Cook Islands",
                                    "Costa Rica",
                                    "Cote D'ivoire",
                                    "Croatia",
                                    "Cuba",
                                    "Cyprus",
                                    "Czech Republic",
                                    "Denmark",
                                    "Djibouti",
                                    "Dominica",
                                    "Dominican Republic",
                                    "Ecuador",
                                    "Egypt",
                                    "El Salvador",
                                    "Equatorial Guinea",
                                    "Eritrea",
                                    "Estonia",
                                    "Ethiopia",
                                    "Falkland Islands (Malvinas)",
                                    "Faroe Islands",
                                    "Fiji",
                                    "Finland",
                                    "France",
                                    "French Guiana",
                                    "French Polynesia",
                                    "French Southern Territories",
                                    "Gabon",
                                    "Gambia",
                                    "Georgia",
                                    "Germany",
                                    "Ghana",
                                    "Gibraltar",
                                    "Greece",
                                    "Greenland",
                                    "Grenada",
                                    "Guadeloupe",
                                    "Guam",
                                    "Guatemala",
                                    "Guernsey",
                                    "Guinea",
                                    "Guinea-bissau",
                                    "Guyana",
                                    "Haiti",
                                    "Heard Island and Mcdonald Islands",
                                    "Holy See (Vatican City State)",
                                    "Honduras",
                                    "Hong Kong",
                                    "Hungary",
                                    "Iceland",
                                    "India",
                                    "Indonesia",
                                    "Iran, Islamic Republic of",
                                    "Iraq",
                                    "Ireland",
                                    "Isle of Man",
                                    "Israel",
                                    "Italy",
                                    "Jamaica",
                                    "Japan",
                                    "Jersey",
                                    "Jordan",
                                    "Kazakhstan",
                                    "Kenya",
                                    "Kiribati",
                                    "Korea, Democratic People's Republic of",
                                    "Korea, Republic of",
                                    "Kuwait",
                                    "Kyrgyzstan",
                                    "Lao People's Democratic Republic",
                                    "Latvia",
                                    "Lebanon",
                                    "Lesotho",
                                    "Liberia",
                                    "Libyan Arab Jamahiriya",
                                    "Liechtenstein",
                                    "Lithuania",
                                    "Luxembourg",
                                    "Macao",
                                    "Macedonia, The Former Yugoslav Republic of",
                                    "Madagascar",
                                    "Malawi",
                                    "Malaysia",
                                    "Maldives",
                                    "Mali",
                                    "Malta",
                                    "Marshall Islands",
                                    "Martinique",
                                    "Mauritania",
                                    "Mauritius",
                                    "Mayotte",
                                    "Mexico",
                                    "Micronesia, Federated States of",
                                    "Moldova, Republic of",
                                    "Monaco",
                                    "Mongolia",
                                    "Montenegro",
                                    "Montserrat",
                                    "Morocco",
                                    "Mozambique",
                                    "Myanmar",
                                    "Namibia",
                                    "Nauru",
                                    "Nepal",
                                    "Netherlands",
                                    "Netherlands Antilles",
                                    "New Caledonia",
                                    "New Zealand",
                                    "Nicaragua",
                                    "Niger",
                                    "Nigeria",
                                    "Niue",
                                    "Norfolk Island",
                                    "Northern Mariana Islands",
                                    "Norway",
                                    "Oman",
                                    "Pakistan",
                                    "Palau",
                                    "Palestinian Territory, Occupied",
                                    "Panama",
                                    "Papua New Guinea",
                                    "Paraguay",
                                    "Peru",
                                    "Philippines",
                                    "Pitcairn",
                                    "Poland",
                                    "Portugal",
                                    "Puerto Rico",
                                    "Qatar",
                                    "Reunion",
                                    "Romania",
                                    "Russian Federation",
                                    "Rwanda",
                                    "Saint Helena",
                                    "Saint Kitts and Nevis",
                                    "Saint Lucia",
                                    "Saint Pierre and Miquelon",
                                    "Saint Vincent and The Grenadines",
                                    "Samoa",
                                    "San Marino",
                                    "Sao Tome and Principe",
                                    "Saudi Arabia",
                                    "Senegal",
                                    "Serbia",
                                    "Seychelles",
                                    "Sierra Leone",
                                    "Singapore",
                                    "Slovakia",
                                    "Slovenia",
                                    "Solomon Islands",
                                    "Somalia",
                                    "South Africa",
                                    "South Georgia and The South Sandwich Islands",
                                    "Spain",
                                    "Sri Lanka",
                                    "Sudan",
                                    "Suriname",
                                    "Svalbard and Jan Mayen",
                                    "Swaziland",
                                    "Sweden",
                                    "Switzerland",
                                    "Syrian Arab Republic",
                                    "Taiwan (ROC)",
                                    "Tajikistan",
                                    "Tanzania, United Republic of",
                                    "Thailand",
                                    "Timor-leste",
                                    "Togo",
                                    "Tokelau",
                                    "Tonga",
                                    "Trinidad and Tobago",
                                    "Tunisia",
                                    "Turkey",
                                    "Turkmenistan",
                                    "Turks and Caicos Islands",
                                    "Tuvalu",
                                    "Uganda",
                                    "Ukraine",
                                    "United Arab Emirates",
                                    "United Kingdom",
                                    "United States Minor Outlying Islands",
                                    "Uruguay",
                                    "Uzbekistan",
                                    "Vanuatu",
                                    "Venezuela",
                                    "Viet Nam",
                                    "Virgin Islands, British",
                                    "Virgin Islands, U.S.",
                                    "Wallis and Futuna",
                                    "Western Sahara",
                                    "Yemen",
                                    "Zambia",
                                    "Zimbabwe",
                                ],
            ];
  
    $options['ts1']  = $options['zp'];
    $options['ts2']  = $options['zp'];
    $options['ts2L'] = $options['zp'];
    $options['ts3']  = $options['zp'];
    $options['ts3L'] = $options['zp'];
    $options['ts4']  = $options['zp'];
    $options['ts4L'] = $options['zp'];
    
    $options['bs1']  = $options['zp'];
    $options['bs2']  = $options['zp'];
    $options['bs2L'] = $options['zp'];
    $options['bs3']  = $options['zp'];
    $options['bs3L'] = $options['zp'];
    $options['bs4']  = $options['zp'];
    $options['bs4L'] = $options['zp'];
    $options['bs5']  = $options['zp'];
    $options['bs5L'] = $options['zp'];
    
    $options['le1']  = $options['zp'];
    $options['le2']  = $options['zp'];
    $options['le2L'] = $options['zp'];
    $options['le3']  = $options['zp'];
    $options['le3L'] = $options['zp'];
    $options['le4']  = $options['zp'];
    $options['le4L'] = $options['zp'];
    $options['le5']  = $options['zp'];
    $options['le5L'] = $options['zp'];
  
    $options['brace-01']  = $options['zp'];
    $options['brace-02']  = $options['zp'];
    $options['brace-03']  = $options['zp'];
    $options['brace-04']  = $options['zp'];
    $options['brace-05']  = $options['zp'];
    $options['brace-06']  = $options['zp'];
    $options['brace-07']  = $options['zp'];
    $options['brace-08']  = $options['zp'];
    $options['brace-09']  = $options['zp'];
    $options['brace-1L'] = $options['zp'];
    $options['brace-2L'] = $options['zp'];
    $options['brace-3L'] = $options['zp'];
    $options['brace-4L'] = $options['zp'];
    $options['brace-5L'] = $options['zp'];
    $options['brace-6L'] = $options['zp'];
    $options['brace-7L'] = $options['zp'];
    $options['brace-8L'] = $options['zp'];
    $options['brace-9L'] = $options['zp'];
    $options['ribs-color']  = $options['ft30'];
    $options['rib-01']  = $options['zp'];
    $options['rib-02']  = $options['ft30'];
    $options['rib-03']  = $options['zp'];
    $options['rib-04']  = $options['zp'];
    $options['rib-05']  = $options['ft30'];
    $options['rib-06']  = $options['zp'];
    $options['rib-07']  = $options['zp'];
    $options['rib-08']  = $options['ft30'];
    $options['rib-09']  = $options['zp'];
    $options['rib-10']  = $options['zp'];
    $options['rib-1L']  = $options['zp'];
    $options['rib-2L']  = $options['ft30'];
    $options['rib-3L']  = $options['zp'];
    $options['rib-4L']  = $options['zp'];
    $options['rib-5L']  = $options['ft30'];
    $options['rib-6L']  = $options['zp'];
    $options['rib-7L']  = $options['zp'];
    $options['rib-8L']  = $options['ft30'];
    $options['rib-9L']  = $options['zp'];
    $options['rib-10L']  = $options['zp'];
    
    $options['cg1'] = $options['zp'];
    $options['cg2']  = $options['zp'];
    $options['cg3'] = $options['zp'];
    $options['cg4']  = $options['zp'];
    $options['cg5'] = $options['zp'];
  
    
    //this is applying mode according to hybrid
    //this is applying mode according to hybrid
    //this is applying mode according to hybrid
    /*$_GET['mode'] = isset($_GET['mode']) ? $_GET['mode'] : 'hybrid1';
    
    if($_GET['mode'] == 'hybrid1')
    {
        $options['ts1']  = $options['ft30'];
        $options['ts2']  = $options['ft30'];
        $options['ts2L'] = $options['ft30'];
        $options['ts3']  = $options['ft30'];
        $options['ts3L'] = $options['ft30'];
        $options['ts4']  = $options['ft30'];
        $options['ts4L'] = $options['ft30'];
        
        $options['ribs_color'] = $options['ft30'];
        
        $options['bs1']  = $options['zp'];
        $options['bs2']  = $options['zp'];
        $options['bs2L'] = $options['zp'];
        $options['bs3']  = $options['zp'];
        $options['bs3L'] = $options['zp'];
        $options['bs4']  = $options['zp'];
        $options['bs4L'] = $options['zp'];
        
        $options['brace-01'] = $options['zp'];
        $options['brace-02'] = $options['zp'];
        $options['brace-03'] = $options['zp'];
        $options['brace-04'] = $options['zp'];
        $options['brace-05'] = $options['zp'];
        $options['brace-06'] = $options['zp'];
        $options['brace-1L'] = $options['zp'];
        $options['brace-2L'] = $options['zp'];
        $options['brace-3L'] = $options['zp'];
        $options['brace-4L'] = $options['zp'];
        $options['brace-5L'] = $options['zp'];
        $options['brace-6L'] = $options['zp'];
    }
    else
    {
        $options['ts1']  = $options['zp'];
        $options['ts2']  = $options['zp'];
        $options['ts2L'] = $options['zp'];
        $options['ts3']  = $options['zp'];
        $options['ts3L'] = $options['zp'];
        $options['ts4']  = $options['zp'];
        $options['ts4L'] = $options['zp'];
        
        $options['bs1']  = $options['zp'];
        $options['bs2']  = $options['zp'];
        $options['bs2L'] = $options['zp'];
        $options['bs3']  = $options['zp'];
        $options['bs3L'] = $options['zp'];
        $options['bs4']  = $options['zp'];
        $options['bs4L'] = $options['zp'];
        
        $options['ribs_color'] = $options['ft30'];
        $options['brace-01'] = $options['ft30'];
        $options['brace-02'] = $options['ft30'];
        $options['brace-03'] = $options['ft30'];
        $options['brace-04'] = $options['ft30'];
        $options['brace-05'] = $options['ft30'];
        $options['brace-06'] = $options['ft30'];
        $options['brace-1L'] = $options['ft30'];
        $options['brace-2L'] = $options['ft30'];
        $options['brace-3L'] = $options['ft30'];
        $options['brace-4L'] = $options['ft30'];
        $options['brace-5L'] = $options['ft30'];
        $options['brace-6L'] = $options['ft30'];
      
    }
    */
    
?>